#include "MyersTriangle.h"

TriangleType VerifyTriangle(int a, int b, int c)
{
	
}
